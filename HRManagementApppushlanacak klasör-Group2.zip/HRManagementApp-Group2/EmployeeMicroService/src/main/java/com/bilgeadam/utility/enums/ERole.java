package com.bilgeadam.utility.enums;

public enum ERole {
    ADMIN,EMPLOYEE,MANAGER
}
